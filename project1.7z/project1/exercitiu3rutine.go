package main
import "fmt"
import ("time"
	//"runtime"
)

func numarare(){                     //functie generare alfabet
	for i:=0;i<=30;i++ {
		if ((i % 2) == 0) {
			fmt.Println(i) //trimitem literele pe un canal
			//channel <- int(i)
		}
	}
	//close(channel)
}

//func afisare(channel chan int){
//	for {
//		fmt.Println(<-channel)
//	}
///}
func main() {

	//channel := make(chan int)
	//runtime.GOMAXPROCS(8) //n este nr de procesoare , pentru lucrul paralel ;fiecare procesor ia o parte din citire
	go numarare()   //o functie sa fie rutina : go numele_functiei
	//go afisare(channel)
	time.Sleep(5 * time.Second) //asteapta sa se termine rutina si dupa si main ul.

}




