package main
import "fmt"

type Salut struct{        //definesc o structura
	nume string
	mesaj string
}

var t=Salut{} //structura vidaaaaaaaaaaaaaaaa


func main () {

	var S = Salut{"Alexandra","Hei"}
	fmt.Println(S.nume)
	fmt.Println(t)
}

