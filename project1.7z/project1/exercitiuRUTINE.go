package main
import "fmt"
import ("time"
	"runtime"
)

func alfabet(channel chan string){                     //functie generare alfabet
	for i:='a';i<='z';i++{
		//fmt.Println(string(i))
		channel <- string(i) //trimitem literele pe un canal
	}
	close(channel)
}

func afisare(channel chan string){
	for  {
		fmt.Printf(<-channel)          //afiseaza litere pe cate un canal
	}
}
func main() {

	channel := make(chan string)
	runtime.GOMAXPROCS(8) //n este nr de procesoare , pentru lucrul paralel ;fiecare procesor ia o parte din citire
	go alfabet(channel)   //o functie sa fie rutina : go numele_functiei
	go afisare(channel)
	time.Sleep(5 * time.Second) //asteapta sa se termine rutina si dupa si main ul.

}




