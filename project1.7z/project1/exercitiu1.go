package main
import "fmt"

type Salut string  //definesc un tip Salut care este string
var mesaj Salut
var sintagma *Salut = &mesaj //pointerul variabilei mesaj

func main () {

	mesaj = "Salut"
	fmt.Println(mesaj,sintagma) //afisare mesaj si pointer
}

